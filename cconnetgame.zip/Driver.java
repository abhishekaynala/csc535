
public class Driver  {
    public static void main(String[] args)
    {
        TicTacToeGame g = new TicTacToeGameGame();
        g.play();

    }
}
